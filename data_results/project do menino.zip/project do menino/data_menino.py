import numpy as np
import matplotlib.pyplot as plt
import matplotlib.tri as tri
from mpl_toolkits.mplot3d import Axes3D

# Ler arquivo
with open("dados_do_menino.txt", 'r') as f:
    s = f.read().splitlines()

# Ler headers da primeira linha
headers = s[0].split('\t')
# Ler restante dos dados em matriz
data = np.array([[float(x) for x in line.split('\t')] for line in s[1:]])

# Alocar dados em vetores
# # Variáveis independentes
x0 = data[:,0]
xf = data[:,1]
y0 = data[:,2]
yf = data[:,3]

# # Variáveis adicionais
tb = data[:,5]
tw = data[:,6]
n = data[:,7]
k = data[:,8]

# # Variáveis dependentes
p = data[:,9]
t = data[:,4]
r = data[:,10]

# Definição das variáveis para plotagem
x = y0
y = yf
z = r

# Definição dos objetos de triangulação para plotagem
triang = tri.Triangulation(x, y)

# Plot 1 - Curvas de nível
fig1,ax1 = plt.subplots()
# plt.gca().set_aspect('equal')
plt.tricontourf(triang, z, levels=np.linspace(np.min(z),np.max(z),30))
plt.colorbar()
# plt.tricontour(triang, z, colors='k')
# plt.title('Contour plot of Delaunay triangulation')

# Redefinição das variáveis para plotagem
x = x0
y = y0
colors = t
area = 300**(0.3+z)
# ax1.set_aspect('equal')

# x = np.log10(t)
# y = r
# colors = x0
# area = 300**(1-y0)  # 0 to 15 point radii

# Plot 2 - Scatter bidimensional
fig2,ax2 = plt.subplots()
sc = ax2.scatter(x, y, s=area, c=colors, alpha=0.5, cmap=plt.cm.viridis_r)
ax2.set_xlabel('X Label')
ax2.set_ylabel('Y Label')
plt.colorbar(sc)

# Redefinição das variáveis para plotagem
x = x0
y = y0
z = r
vx = xf/20
vy = yf/20
vz = 0
colors = np.log10(t)
colors -= np.min(colors)
colors /= np.max(colors)
colors = np.array((colors, 1 - colors, np.zeros(len(t)))).T
area = 300**(0.3+z)  # 0 to 15 point radii

# Plot 3 - Quiver tridimensional
fig=plt.figure()
ax3=fig.add_subplot(111, projection='3d')
ax3.quiver(x,y,z,vx,vy,vz,color=colors)

ax3.set_xlabel('X Label')
ax3.set_ylabel('Y Label')
ax3.set_zlabel('Z Label')
ax3.set_title('Title')

plt.show()